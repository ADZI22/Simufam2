##Les tables de mortalité proviennent du site de l'INSEE et date de 2022
##Nous supposons que la mortalité dans notre population suivie est la même que celle dans la population générale

###calcul de la probilité cumulé de décès chez les Hommes
Mortalite_M_age_actuel <- vector("list",105)
names(Mortalite_M_age_actuel) <- as.character(0:104)

mortalite_M <-readxl::read_excel("C:/Users/etudiant/Documents/EMILIE/STAGE_M2/CLB/SEANCE_DE_TRAVAIL/Mortalite_insee_2022.xlsx", sheet = 1)
mortalite_M <- mortalite_M %>%
  mutate(Risque_t = Deces / Survivants,
         Risque_cum = NA)

for (age in 0:104){
  temp <- mortalite_M %>%
    filter(Age >= age)

  temp$Risque_cum[1] <- temp$Risque_t[1]

  if (nrow(temp) >  1) {
    for (t in 2: nrow(temp)){
      #Proba_cum_t = [décéder avant t] OU [etre vivant à t-1 ET décéder au temps t]
      temp$Risque_cum[t] <- temp$Risque_cum[t-1] + (1 - temp$Risque_cum[t-1])*temp$Risque_t[t]
    }
  }
  Mortalite_M_age_actuel[[as.character(age)]] <- temp
}

usethis::use_data(Mortalite_M_age_actuel)



###calcul de la probilité cumulé de décès chez les Femmes
Mortalite_F_age_actuel <- vector("list",105)
names(Mortalite_F_age_actuel) <- as.character(0:104)

mortalite_F <-readxl::read_excel("C:/Users/etudiant/Documents/EMILIE/STAGE_M2/CLB/SEANCE_DE_TRAVAIL/Mortalite_insee_2022.xlsx", sheet = 2)
mortalite_F <- mortalite_F %>%
  mutate(Risque_t = Deces / Survivantes,
         Risque_cum = NA)

for (age in 0:104){
  temp <- mortalite_F %>%
    filter(Age >= age)

  temp$Risque_cum[1] <- temp$Risque_t[1]

  if (nrow(temp) >  1) {
    for (t in 2: nrow(temp)){
      temp$Risque_cum[t] <- temp$Risque_cum[t-1] + (1 - temp$Risque_cum[t-1])*temp$Risque_t[t]
    }
  }
  Mortalite_F_age_actuel[[as.character(age)]] <- temp
}

usethis::use_data(Mortalite_F_age_actuel)

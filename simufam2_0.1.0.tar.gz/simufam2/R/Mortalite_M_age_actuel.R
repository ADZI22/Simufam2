#' Mortality table of men
#'
#' It contains mortality tables based on the individual's current age.
#' For each possible age, a mortality table is associated with it.
#'
#' @format A list of length 105, each element of the list is a data frame:
#' \describe{
#'   \item{Age}{Age}
#'   \item{Survivants}{Number of men who survived at a specific age.}
#'   \item{Deces}{Number of men who dieh at a specific age.}
#'   \item{Quotient de mortalité}{The probability for the 1000 men at this age to die before the next age.}
#'   \item{Espérance_E(x)}{Life expectancy at a specific age.}
#'   \item{Risque_t}{Instantaneous risk of death at a specific age.}
#'   \item{Risque_cum}{Cumulative risk of death.}

#' }
#' @source INSEE, 2022
#' @examples
#' #To be completed

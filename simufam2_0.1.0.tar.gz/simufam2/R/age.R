#' Empirical age distribution of OFELY database
#'
#' This dataset contains the empirical age distribution per generation and their kinship whit the index case.
#'
#' @format A data frame with 776 rows and 3 columns:
#' \describe{
#'   \item{g_kin}{Concatenation of generation and kinship.}
#'   \item{age_ddn}{ Age of the person.}
#'   \item{n}{Number of person.}
#' }
#' @source OFELY, 2025
#' @examples
#' #To be completed
"data_age"

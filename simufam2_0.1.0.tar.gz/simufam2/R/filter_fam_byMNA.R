#' This function selects families with a minimum number of members with cancer
#'
#' @param families The family population from which the selection is made
#' @param nma minimum number of people affected
#'
#' @returns table of family with a minimum number of people affected
#' @export
#'
#' @importFrom dplyr filter
#'
#' @examples
#' # to be completed
filter_fam_byMNA <- function(families, nma){
  nb <- with(families, table(id_family, Phenotype)[,2])
  fam_sel <- names(nb[nb >= nma])
  cat("nb fam = ", length(fam_sel),"\n")
  out <- families |>  dplyr::filter(id_family %in% fam_sel)

  return(out)
}

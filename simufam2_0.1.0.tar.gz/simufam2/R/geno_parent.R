#' This function calculates the probability of the parents' possible genotype based on that of their child.
#'
#' @param fA allelic frequency.
#'
#' @returns A table of different possibilities of parent's genotype and the probabities associated based on their child one.
#' @export
#'
#' @import dplyr
#' @examples
#' #to be completed
geno_parent <- function(fA){

  geno_HWE <- genotypes_HWE(fA)
  Pr_aa <- geno_HWE$Pr_aa
  Pr_aA <- geno_HWE$Pr_aA
  Pr_AA <- geno_HWE$Pr_AA

  geno <- data.frame(
    geno_child = rep(c(0,1,2), each=9),
    geno_dad = rep(rep(c(0,1,2), each = 3),time=3),
    geno_mum = rep(c(0,1,2), time=9),
    proba = c(Pr_aa*Pr_aa/Pr_aa,
              Pr_aa*Pr_aA*1/2/Pr_aa,
              0,
              Pr_aa*Pr_aA*1/2/Pr_aa,
              Pr_aA*Pr_aA*1/2/Pr_aa,
              0, 0, 0, 0,

              0,
              Pr_aa*Pr_aA*1/2/Pr_aA,
              Pr_aa*Pr_AA/Pr_aA,
              Pr_aa*Pr_aA*1/2/Pr_aA,
              Pr_aA*Pr_aA*1/2/Pr_aA,
              Pr_AA*Pr_aA*1/2/Pr_aA,
              Pr_AA*Pr_aa/Pr_aA,
              Pr_AA*Pr_aA*1/2/Pr_aA,
              0,
              0, 0, 0, 0,
              (Pr_aA*Pr_aA*1/2*1/2)/Pr_AA,
              (Pr_aA*Pr_AA*1/2)/Pr_AA,
              0,
              (Pr_aA*Pr_AA*1/2)/Pr_AA,
              (Pr_AA*Pr_AA)/Pr_AA
    )

    #tapply(d$proba, d$geno_child, sum)
  ) |>

    dplyr::filter(proba > 0) |>
    dplyr::group_by(geno_child) |>
    dplyr::mutate(prob_cum = cumsum(proba)) |>
    dplyr::ungroup()

  return(geno)


}

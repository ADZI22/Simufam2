#' This function calculates the selection probabilities of a confuration of the genotype of the index case and its parents
#'
#' @param fA the allelic frequency
#'
#' @returns table of different possibilities of genotype of the index case and its parents and the probabilities associated
#' @export
#'
#' @importFrom dplyr filter
#' @importFrom dplyr mutate
#' @examples
#' #to be completed
geno_trio <- function(fA){

  geno_HWE <- genotypes_HWE(fA)
  Pr_aa <- geno_HWE$Pr_aa
  Pr_aA <- geno_HWE$Pr_aA
  Pr_AA <- geno_HWE$Pr_AA

  geno_tab <- data.frame(
    geno_index = rep(1, 9),
    geno_dad = rep(c(0,1,2), each = 3),
    geno_mum = rep(c(0,1,2), times = 3),
    proba = c(0,
              Pr_aa*Pr_aA*1/2,
              Pr_aa*Pr_AA,
              Pr_aA*Pr_aa*1/2,
              Pr_aA*Pr_aA*1/2,
              Pr_aA*Pr_AA*1/2,
              Pr_AA*Pr_aa,
              Pr_aA*Pr_AA*1/2,
              0
    )
  ) |>

    dplyr::filter(proba > 0) |>
    dplyr::mutate(prob_trio = (proba/sum(proba))) |>
    dplyr::mutate(prob_cum = cumsum(prob_trio))

  return(geno_tab)

}

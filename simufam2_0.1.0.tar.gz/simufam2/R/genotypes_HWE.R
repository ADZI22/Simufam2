#' function that computes the Hardy-Weinberg genotype probabilities
#'
#' @param fA the allelic frequency
#'
#' @returns a list of probabilities
#' @export
#'
#' @examples
#' #R code to be completed
genotypes_HWE <- function(fA){
  ## hardy-weinberg equilibrium probabilities
  Pr_aa <- (1-fA)**2
  Pr_aA <- 2*(1-fA)*fA
  Pr_AA <- fA**2
  #
  return(list("Pr_aa" = Pr_aa,
              "Pr_aA" = Pr_aA,
              "Pr_AA" = Pr_AA))
}

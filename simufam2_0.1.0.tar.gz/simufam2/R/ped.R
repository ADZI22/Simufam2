#' Family data from Bonaiti publication ped
#'
#' This dataset contains family information from the Bonaiti publication's sample family.
#' It includes details on family members, their relations, and their kinship coefficients.
#'
#' @format A data frame with 38 rows and 6 columns:
#' \describe{
#'   \item{id}{Unique identifier for each family member.}
#'   \item{dadid}{Identifier for the father of each family member.}
#'   \item{momid}{Identifier for the mother of each family member.}
#'   \item{sex}{Sex of the family member: 'Male' or 'Female'.}
#'   \item{generation}{Generation of the family member. The index case (id 17) is marked as generation 0.}
#'   \item{kin_id17}{Kinship coefficient with the index case (id 17).}
#' }
#' @source Bonaiti, "Estimating penetrance from multiple case families with predisposing mutations: extension of the 'genotype-restricted likelihood' (GRL) method."
#' @examples
#' data(ped)  # Load the family data
#' head(ped)  # Show the first few rows of the data
"ped"

#' This function estimates a penetrance
#'
#' @param d the lifetime penetrance
#' @param H1 the proportion of unaffected at t1 years among at risk individuals
#' @param H2 the proportion of unaffected at t2 years among unaffected at t1 but at risk at t2
#' @param t1 40 years old
#' @param t2 70 years old
#'
#' @returns A vector of penetrance of each age
#' @export
#'
#' @examples
#' ##To be completed
penetrance.Weibull <- function(d, H1, H2, t1 = 40, t2 = 70){

  # Internal parameters a, k and l derived from d, H1 and H2
  a  <- (log(-log(H1*H2)) - log(-log(H1)))/(log(t2) - log(t1))
  k  <- 1 - d
  l  <- exp(log(-log(H1))/a - log(t1))

  # code to do the reverse operation (ie a,k,l to d,H1,H2)
  # d <- 1 - k
  # H1 <- exp(-(l*t1)^a)
  # H2 <- exp(-(l*t2)^a)/exp(-(l*t1)^a)

  tt <- 0:120

  out <- (1 - k)*(1 - exp(-(l*tt)^a))
  out[1] <- 0.
  names(out) <- tt

  return(out)


}

#' This function can be used to select at random a number of families with a single mutation in a specific population of families with the same cancer risk.
#'
#' @param families Family population from which to select
#' @param nb_fam number of families to be selected in the sample
#'
#' @returns A table of family with characteristics of each member
#' @import dplyr
#'
#' @export
#'
#' @examples
#' #To be completed
sample_fam <- function(families, nb_fam){

  doublemut <- unique(families$id_family[families$genotype == 2])

  families_singlemut <- families %>% dplyr::filter(!id_family %in% doublemut)

  vect <- unique(families_singlemut$id_family)
  sample_fam <- sample(x = vect, size = nb_fam, replace = FALSE)

  out <- families_singlemut %>%
    dplyr::filter(id_family %in% sample_fam)

  return(out)
}

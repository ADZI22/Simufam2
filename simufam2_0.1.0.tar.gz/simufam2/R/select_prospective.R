#' This function selects a prospective cohort from a previous family simulated.
#'
#' @param families families from which individuals are selected for the cohort
#' @param t cohort follow-up time
#'
#' @returns A table of individuals with their characteristics, including age at death and age at cancer
#'
#' @import dplyr
#'
#'
#' @export
#'
#' @examples
#' #To be completed
select_prospective <- function (families, t) {

  ##Calcul de lâge après 10 ans de suivi
  out <- families %>%
    dplyr::filter(Phenotype == 0) %>% ##indemne de cancer
    dplyr::filter(tested == 1) %>% ##Les individus testées
    dplyr::filter(genotype >= 1) %>% ## porteur de la mutation
    dplyr::filter(age_ddn <= 80) %>% ##Ne pas inclure après 80 ans
    dplyr::mutate(age_fsuivi = age_ddn + t)  ##âge après t année de suivi

  #####Simulation de l'âge au décès selon le sexe

  out$age_deces <- NA

  for (age in 0:104){

    #hommes
    wi <- which(out$sex == "Male" & out$age_ddn == age)
    out$age_deces[wi] <- simul_age_deces(n = length(wi), sexe = "Male", age = age)

    #femmes
    wi <- which(out$sex == "Female" & out$age_ddn == age)
    out$age_deces[wi] <- simul_age_deces(n = length(wi), sexe = "Female", age = age)

    cat("age au decès pour l'age", age, "\n")

  }

  ##Créer l'évenement
  out <- out %>%
    dplyr::filter(age_deces > age_ddn) %>%
    dplyr::mutate(event = if_else(age_cancer <= age_fsuivi & age_deces > age_cancer, 1,0)) %>%  #Phénotype après le suivi
    dplyr::mutate (event = if_else (is.na(age_cancer), 0, event)) %>%
    dplyr::mutate(fin_suivi = pmin(age_cancer, age_deces, age_fsuivi, na.rm = T))  ## Temps de suivi dans l'étude

  return(out)
}

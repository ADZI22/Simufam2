#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom stats rbinom
#' @importFrom stats runif
## usethis namespace: end
NULL

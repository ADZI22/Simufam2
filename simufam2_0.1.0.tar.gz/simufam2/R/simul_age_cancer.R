#' This function simulates the age at last news from a risk function (penetrance)
#'
#' @param risk risk function (penetrance)
#' @param n number of people for whom we wish to simulate the latest ages
#'
#' @returns A vector of the age at last news
#' @export
#'
#' @importFrom stats runif
#' @examples
#' #to be completed
simul_age_cancer <- function (risk, n){

  u <- stats::runif(n, min = 0, max = 1)
  age_cancer <- findInterval(u, risk) - 1 ##Simulation de l'âge au cancer

  return(age_cancer)
}

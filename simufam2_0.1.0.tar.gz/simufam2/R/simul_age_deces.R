#' This function simulates the age of death of individuals as a function of sex
#'
#' @param n Number of persons
#' @param age The current age
#' @param sexe a vector of sex
#'
#' @returns A vector for the age of death
#' @export
#' @importFrom dplyr pull
#' @importFrom stats runif
#'
#'
#' @examples
#' ##To be completed
simul_age_deces <- function(n, age, sexe) {

  u <- runif(n = n, min = 0, max = 1)

  ##Table de mortalité en fonction de l'âge et du sexe
  if(sexe == "Male"){
    mortalite <- Mortalite_M_age_actuel[[as.character(age)]]
  }else{
    mortalite <- Mortalite_F_age_actuel[[as.character(age)]]
  }

  #tester les valeurs extrêmes
  #u[1] <- 0.000001
  #u[2] <- 0.999999

  indices <- findInterval(u, mortalite$Risque_cum) + 1


  age_deces <- dplyr::pull(mortalite[indices,], Age)

  return(age_deces)
}


#' This function simulate the genotype of children based on their parents ones
#'
#' @param geno_dad genotype of the dad of the child
#' @param geno_mum genotype of the mum
#'
#' @returns vector of genotype of children
#' @export
#'
#' @importFrom stats rbinom
#' @examples
#' #to be completed
simul_child <- function( geno_dad, geno_mum){

  # simu=rbinom(1, 1, prob= 0.5)
  n <- length(geno_dad)

  child_allele_dad <- rep(0,times = n)
  child_allele_dad[geno_dad == 2] <- 1
  n_dad_1 <- sum(geno_dad == 1)
  child_allele_dad[which(geno_dad == 1)] <- stats::rbinom(n=n_dad_1, size =1, prob= 0.5)

  child_allele_mum <- rep(0,times = n)
  child_allele_mum[geno_mum == 2] <- 1
  n_mum_1 <- sum(geno_mum == 1)
  child_allele_mum[which(geno_mum == 1)] <- stats::rbinom(n=n_mum_1, size =1, prob= 0.5)

  geno_child <- child_allele_dad + child_allele_mum
  # out <- data.frame("geno_dad" = geno_dad,
  #                          "geno_mum" = geno_mum,
  #                          "geno_child"=geno_child)
  # return(out)
  return(geno_child)

}

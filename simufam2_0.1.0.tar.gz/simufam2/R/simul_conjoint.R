#' This function randomly simulates the genotype of the spouses
#'
#' @param fA allelic frequency
#' @param n number of families
#'
#' @returns a vector of the genotype of spouce
#' @export
#'
#' @importFrom stats runif
#' @examples
#' #to be completed
simul_conjoint <- function (fA, n){

  ##Probabilité cumulée
  proba_geno <- genotypes_HWE(fA=fA)
  prob_cum <- cumsum(proba_geno)
  #geno <- c(0,1,2)
  #geno_initial <- data.frame(geno, proba_geno, prob_cum)

  ##Simuler un conjoint
  u <- stats::runif(n, min=0,  max=1)
  #indices <- findInterval(u, prob_cum) +1 # Trouver l'index correspondant
  out <- findInterval(u, prob_cum)

  return(out)
  #Retourner le génotype du conjoint
  #return(data.frame(geno_initial[indices, "geno"]))

}

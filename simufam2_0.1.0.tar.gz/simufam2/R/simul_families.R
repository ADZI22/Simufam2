#' This function simulates families with the index case carrying the MMR mutation
#'
#' @param fA allelic frequency
#' @param n number of families
#' @param risk_mute penetrance in mutation carriers
#' @param risk_nmute penetrance in general population
#'
#' @import dplyr
#' @importFrom tidyr pivot_longer
#' @importFrom stats rbinom
#' @returns A table of family with characteristics of each member
#' @export
#'
#' @examples
#' #to be completed
simul_families <- function(fA, n, risk_mute, risk_nmute){

  ## Simuler le trio de départ
  trio_index <- simul_trio(n = n, fA = fA)
  geno_17 <- trio_index$geno_index
  geno_7 <- trio_index$geno_dad
  geno_8 <- trio_index$geno_mum

  ## Les frères du cas index
  geno_15 <- simul_child(geno_7, geno_8)
  geno_20 <- simul_child(geno_7, geno_8)

  ## Les conjoints du cas index et de ses frères
  geno_16 <- simul_conjoint(fA = fA, n=n)
  geno_19 <- simul_conjoint(fA = fA, n=n)
  geno_18 <- simul_conjoint(fA = fA, n=n)

  ## Les enfants du cas index et de ses frères
  geno_29 <- simul_child(geno_dad = geno_15, geno_mum = geno_16)
  geno_30 <- simul_child(geno_dad = geno_15, geno_mum = geno_16)
  geno_31 <- simul_child(geno_dad = geno_17, geno_mum = geno_18)
  geno_32 <- simul_child(geno_dad = geno_17, geno_mum = geno_18)
  geno_33 <- simul_child(geno_dad = geno_19, geno_mum = geno_20)
  geno_34 <- simul_child(geno_dad = geno_19, geno_mum = geno_20)

  ## Simuler les grands-parents du cas index

  temp_7 <- simul_parent(geno_7, fA = fA)
  geno_1 <- temp_7$geno_dad
  geno_2 <- temp_7$geno_mum

  temp_8 <- simul_parent(geno_8, fA = fA)
  geno_3 <- temp_8$geno_dad
  geno_4 <- temp_8$geno_mum

  ## Oncle 5 du cas index et son épouse
  geno_5 <- simul_child(geno_dad = geno_1, geno_mum = geno_2)
  geno_6 <- simul_conjoint(fA = fA, n=n)

  ## Les cousins du cas index (enfant de l'oncle 5)
  geno_12 <- simul_child(geno_dad = geno_5, geno_mum = geno_6)
  geno_13 <- simul_child(geno_dad = geno_5, geno_mum = geno_6)

  ## Conjoints des cousins du cas index
  geno_11 <- simul_conjoint(fA = fA, n = n)
  geno_14 <- simul_conjoint(fA = fA, n = n)

  ## Les neuveux/nièces du cas index
  geno_25 <- simul_child(geno_dad = geno_11, geno_mum = geno_12)
  geno_26 <- simul_child(geno_dad = geno_11, geno_mum = geno_12)
  geno_27 <- simul_child(geno_dad = geno_13, geno_mum = geno_14)
  geno_28 <- simul_child(geno_dad = geno_13, geno_mum = geno_14)

  ## Oncle 9 et son épouse
  geno_9 <- simul_child(geno_dad = geno_3, geno_mum = geno_4)
  geno_10 <- simul_conjoint(fA = fA, n = n)

  ## Les enfants de l'oncle 9 (cousins/ cousines du cas index)
  geno_21 <- simul_child(geno_dad = geno_9, geno_mum = geno_10)
  geno_24 <- simul_child(geno_dad = geno_9, geno_mum = geno_10)

  ## Conjoints des cousins 21 et 24
  geno_22 <- simul_conjoint(fA = fA, n = n)
  geno_23 <- simul_conjoint(fA = fA, n = n)

  ## Enfants de 21 et 22, 23 et 24
  geno_35 <- simul_child(geno_dad = geno_21, geno_mum = geno_22)
  geno_36 <- simul_child(geno_dad = geno_21, geno_mum = geno_22)
  geno_37 <- simul_child(geno_dad = geno_23, geno_mum = geno_24)
  geno_38 <- simul_child(geno_dad = geno_23, geno_mum = geno_24)


  families <- data.frame(geno_1, geno_2, geno_3, geno_4,
                         geno_5, geno_6, geno_7, geno_8,
                         geno_9, geno_10, geno_11, geno_12,
                         geno_13, geno_14, geno_15, geno_16,
                         geno_17, geno_18, geno_19, geno_20,
                         geno_21, geno_22, geno_23, geno_24,
                         geno_25, geno_26, geno_27, geno_28,
                         geno_29, geno_30, geno_31, geno_32,
                         geno_33, geno_34, geno_35, geno_36,
                         geno_37, geno_38)

  out <- families %>% ####Pivoter la jeu de données pour avoir un jeu en ligne
    tidyr::pivot_longer(cols = everything(),
                        names_to = "id_individu",
                        values_to = "genotype") %>%
    mutate(id_family = rep(1:n, each = 38)) %>%
    relocate(id_family)  ###Mettre les id de la famille à la première colonne


  ###Ajout de la génération des id, sexes, des générations et du coeficient d'apparenté
  out <- out %>%
    left_join(ped, by = c("id_individu"="temp")) %>%
    select(-id_individu)


  ####

  ####Simulation de l'âge aux dernières nouvelles à partir des calcluls dans la base OFELY
  out$age_ddn <- 0
  out$tested <-0

  wi <- which(out$cod == "0_1")
  # out$age_ddn[wi] <- simul_age_ddn(n = length(wi), age_mean=56, age_sd=13)
  out$tested[wi] <- 1
  out$age_ddn[wi] <- sample(x = data_age$age_ddn[data_age$g_kin == "0_1"] ,size = length(wi) ,
                            replace = TRUE , prob = data_age$proba[data_age$g_kin == "0_1"] )

  wi <- which(out$cod == "0_0")
  # out$age_ddn[wi] <- simul_age_ddn(n = length(wi), age_mean = 58, age_sd = 13)
  out$tested[wi] <- rbinom(n = length(wi), size = 1, prob = 0.1765)
  out$age_ddn[wi] <- sample(x = data_age$age_ddn[data_age$g_kin == "0_0"] ,size = length(wi) ,
                            replace = TRUE , prob = data_age$proba[data_age$g_kin == "0_0"] )

  wi <- which(out$cod == "0_0.5")
  # out$age_ddn[wi] <- simul_age_ddn(n = length(wi), age_mean = 53, age_sd = 14)
  out$tested[wi] <- rbinom(n = length(wi), size = 1, prob = 0.36 )
  out$age_ddn[wi] <- sample(x = data_age$age_ddn[data_age$g_kin == "0_0.5"] ,size = length(wi) ,
                            replace = TRUE , prob = data_age$proba[data_age$g_kin == "0_0.5"] )

  wi <- which(out$cod == "0_0.125")
  # out$age_ddn[wi] <- simul_age_ddn(n = length(wi), age_mean = 51, age_sd = 14)
  out$tested[wi] <- rbinom(n = length(wi), size = 1, prob = 0.098)
  out$age_ddn[wi] <- sample(x = data_age$age_ddn[data_age$g_kin == "0_0.125"] ,size = length(wi) ,
                            replace = TRUE , prob = data_age$proba[data_age$g_kin == "0_0.125"] )

  wi <- which(out$cod == "1_0.25")
  # out$age_ddn[wi] <- simul_age_ddn(n = length(wi), age_mean = 30, age_sd = 14)
  out$tested[wi] <- rbinom(n = length(wi), size = 1, prob = 0.143)
  out$age_ddn[wi] <- sample(x = data_age$age_ddn[data_age$g_kin == "1_0.25"] ,size = length(wi) ,
                            replace = TRUE , prob = data_age$proba[data_age$g_kin == "1_0.25"] )

  wi <- which(out$cod == "1_0.5")
  # out$age_ddn[wi] <- simul_age_ddn(n = length(wi), age_mean = 29, age_sd = 13)
  out$tested[wi] <- rbinom(n = length(wi), size = 1, prob = 0.578)
  out$age_ddn[wi] <- sample(x = data_age$age_ddn[data_age$g_kin == "1_0.5"] ,size = length(wi) ,
                            replace = TRUE , prob = data_age$proba[data_age$g_kin == "1_0.5"] )

  wi <- which(out$cod == "1_0.0625")
  # out$age_ddn[wi] <- simul_age_ddn(n = length(wi), age_mean = 29, age_sd = 13)
  out$tested[wi] <- rbinom(n = length(wi), size = 1, prob = 0.098 )
  out$age_ddn[wi] <- sample(x = data_age$age_ddn[data_age$g_kin == "1_0.0625"] ,size = length(wi) ,
                            replace = TRUE , prob = data_age$proba[data_age$g_kin == "1_0.0625"] )

  wi <- which(out$cod == "-1_0")
  # out$age_ddn[wi] <- simul_age_ddn(n = length(wi), age_mean = 82, age_sd = 9)
  out$tested[wi] <- 0
  out$age_ddn[wi] <- sample(x = data_age$age_ddn[data_age$g_kin == "-1_0"] ,size = length(wi) ,
                            replace = TRUE , prob = data_age$proba[data_age$g_kin == "-1_0"] )

  wi <- which(out$cod == "-1_0.25")
  # out$age_ddn[wi] <- simul_age_ddn(n = length(wi), age_mean = 68, age_sd = 17)
  out$tested[wi] <- rbinom(n = length(wi), size = 1, prob = 0.053)
  out$age_ddn[wi] <- sample(x = data_age$age_ddn[data_age$g_kin == "-1_0.25"] ,size = length(wi) ,
                            replace = TRUE , prob = data_age$proba[data_age$g_kin == "-1_0.25"] )

  wi <- which(out$cod == "-1_0.5")
  # out$age_ddn[wi] <- simul_age_ddn(n = length(wi), age_mean = 67, age_sd = 16)
  out$tested[wi] <- rbinom(n = length(wi), size = 1, prob = 0.157)
  out$age_ddn[wi] <- sample(x = data_age$age_ddn[data_age$g_kin == "-1_0.5"] ,size = length(wi) ,
                            replace = TRUE , prob = data_age$proba[data_age$g_kin == "-1_0.5"] )

  wi <- which(out$cod == "-2_0.25")
  # out$age_ddn[wi] <- simul_age_ddn(n = length(wi), age_mean = 72, age_sd = 19)
  out$tested[wi] <- rbinom(n = length(wi), size = 1, prob = 0.004)
  out$age_ddn[wi] <- sample(x = data_age$age_ddn[data_age$g_kin == "-2_0.25"] ,size = length(wi) ,
                            replace = TRUE , prob = data_age$proba[data_age$g_kin == "-2_0.25"] )

  #####
  ###Simuler les âges au cancer à partir d'une pénétrance chez les mutés et un
  ##risque donné dans la population générale

  out$age_cancer <- NA

  wi <- which(out$genotype >= 1)
  out$age_cancer[wi] <- simul_age_cancer( risk= risk_mute, n= length(wi))

  wi <- which(out$genotype == 0)
  out$age_cancer[wi] <- simul_age_cancer( risk= risk_nmute, n= length(wi))

  out <- out %>%
    mutate(Phenotype = if_else(age_cancer>age_ddn, 0, 1),
           age_cancer = if_else(age_cancer==120, NA, age_cancer))

  return(out)
}

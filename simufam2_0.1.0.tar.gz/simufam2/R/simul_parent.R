#' This function simulate parent's genotype based on their child one
#'
#' @param child the genotype of the child
#' @param fA allelic frequency
#'
#' @import dplyr
#' @importFrom  stats runif
#' @returns A table of genotype of parents
#' @export
#'
#' @examples
#' #to be completed
simul_parent <- function(child, fA){

  geno <- geno_parent(fA)

  geno_child0 <- geno |> dplyr::filter(geno_child == 0)
  geno_child1 <- geno |> dplyr::filter(geno_child == 1)
  geno_child2 <- geno |> dplyr::filter(geno_child == 2)

  n <- length(child)
  numrow <- 1:n

  out <- data.frame("numrow" = numrow,
                    "child" = child,
                    "u" = stats::runif(n, min=0, max=1))

  out_child0 <- out |> dplyr::filter(child == 0)
  out_child1 <- out |> dplyr::filter(child == 1)
  out_child2 <- out |> dplyr::filter(child == 2)

  geno_parents_child0_indices <- findInterval(out_child0$u, geno_child0$prob_cum) + 1
  geno_dad_child0 <- geno_child0[geno_parents_child0_indices, "geno_dad"]
  geno_mum_child0 <- geno_child0[geno_parents_child0_indices, "geno_mum"]
  out_child0 <- dplyr::bind_cols(out_child0, geno_dad_child0, geno_mum_child0)

  geno_parents_child1_indices <- findInterval(out_child1$u, geno_child1$prob_cum) + 1
  geno_dad_child1 <- geno_child1[geno_parents_child1_indices, "geno_dad"]
  geno_mum_child1 <- geno_child1[geno_parents_child1_indices, "geno_mum"]
  out_child1 <- dplyr::bind_cols(out_child1, geno_dad_child1, geno_mum_child1)

  if(nrow(out_child2)>0){
    geno_parents_child2_indices <- findInterval(out_child2$u, geno_child2$prob_cum) + 1
    geno_dad_child2 <- geno_child2[geno_parents_child2_indices, "geno_dad"]
    geno_mum_child2 <- geno_child2[geno_parents_child2_indices, "geno_mum"]
    out_child2 <- dplyr::bind_cols(out_child2, geno_dad_child2, geno_mum_child2)
  }

  out <- dplyr::bind_rows(out_child0, out_child1, out_child2) |>
    dplyr::arrange(numrow) |>
    dplyr::select(-u, -numrow, -child)

  return(out)

}

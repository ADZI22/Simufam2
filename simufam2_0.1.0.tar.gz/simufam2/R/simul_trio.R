#' This function simulate the index case, his two parents and their genotype
#'
#' @param n number of family to simulate
#' @param fA allelic frequency
#'
#' @returns a vector of the genotype of the index case and his two parents
#' @export
#' @importFrom stats runif
#' @examples
#' #to be completed
simul_trio <- function(n, fA) {

  geno_tab <- geno_trio(fA)

  # trans <- data %>%
  #   mutate(prob_cum=cumsum(Proba))

  u <- stats::runif(n, min=0,  max=1)

  indices <- findInterval(u, geno_tab$prob_cum) + 1 # Trouver l'index correspondant

  return(geno_tab[indices, 1:3]) # Retourner les valeurs sélectionnées

}


ped <- readxl::read_excel("C:/Users/etudiant/Documents/EMILIE/STAGE_M2/CLB/SEANCE_DE_TRAVAIL/DONNEES_BONAITI.xlsx") ##Importation de la famille type de Bonaiti

ped <- ped %>% mutate(generation = case_when(

  ###Creation des générations
  id %in% 1:4 ~ -2,
  id %in% 5:10 ~ -1,
  id %in% 11:24 ~ 0,
  id %in% 25:38 ~ 1),

  ###Creation du degré d'apparenté avec le cas index (id 17)
  kin_id17 = case_when(
    id == 17 ~ 1,
    id %in% c(7, 8, 15, 20, 31, 32 ) ~ 0.5,
    id %in% c(1:5, 9, 29, 30, 31, 33, 34) ~ 0.25,
    id %in% c(12, 13, 21, 24) ~ 0.125,
    id %in% c(25: 28, 35:38) ~ 0.0625,
    TRUE ~ 0),

  cod = paste0(generation, "_", kin_id17),
  temp = paste0("geno_",id)
)

usethis::use_data(ped)
